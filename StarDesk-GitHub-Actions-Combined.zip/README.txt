StarDesk GitHub Actions - combined

Included workflows:
- .github/workflows/cleanup.yml (kept)
- .github/workflows/anydesk-get-id.yml (Windows self-hosted runner; reads AnyDesk ID)

Install both files in your repository at these exact paths.
The AnyDesk workflow requires a registered Windows self-hosted runner with AnyDesk installed.
This does not create a hosted/cloud PC; it runs on your own registered runner.
